package com.tns.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.tns.customer.Customer;
import com.tns.service.CustomerService;

import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/customer") // <-- Needed for correct URL mapping
public class CustomerController {

    @Autowired
    private CustomerService service;

    // GET all customers
    @GetMapping("/customers")
    public List<Customer> list() {
        return service.listAll();
    }

    // GET customer by ID
    @GetMapping("/customers/{id}")
    public ResponseEntity<Customer> get(@PathVariable Integer id) {
        try {
            Customer customer = service.get(id);
            return new ResponseEntity<>(customer, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // POST: Add new customer
    @PostMapping("/customers")
    public void add(@RequestBody Customer customer) {
        service.save(customer);
    }

    // PUT: Update customer
    @PutMapping("/customers/{id}")
    public ResponseEntity<?> update(@RequestBody Customer customer, @PathVariable Integer id) {
        try {
            Customer existCustomer = service.get(id);
            service.save(customer);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // DELETE: Delete customer
    @DeleteMapping("/customers/{id}")
    public void delete(@PathVariable Integer id) {
        service.delete(id);
    }
}